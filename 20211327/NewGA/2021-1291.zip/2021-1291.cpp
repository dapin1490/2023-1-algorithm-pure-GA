#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <set>
#include <algorithm>
#include <cstdlib>
#include <ctime>
#include <chrono>
using namespace std;

#define POP_SIZE 200 // 한 세대를 이루는 해의 총 개수
#define GENERATIONS 1000 // 총 1000 세대
#define TRMT_SIZE 0.14 // 토너먼트에 참여할 해의 비율
#define TRMT_RATE 0.6 // 토너먼트 선택이 발생할 확률
#define CRSOVR_RATE 0.8 // 교차(교배)가 발생할 확률
#define MUTN_RATE 0.05 // 변이가 발생할 확률

double duration;

struct Edge {
    int v1, v2, w; // v1 정점, v2 정점, v1과 v2를 잇는 간선의 가중치 w
};
vector<vector<int>> population; // 한 세대를 이루는 해를 저장하는 컨테이너 생성
vector<Edge> edges; // <v1, v2, w>를 저장하는 컨테이너 생성
int count_V, count_E; // 정점 개수, 간선 개수

void initialize_population() { // 해 생성
    srand(time(NULL));
    for (int i = 0; i < POP_SIZE; ++i) {
        vector<int> individual;
        for (int j = 0; j < count_V; ++j) { // 0 또는 1로 이루어진 count_V 크기의 하나의 해 생성
            individual.push_back(rand() % 2); // individual: 0과 1로 이루어짐
        }
        population.push_back(individual); // 생성한 해를 population 컨테이너에 추가
    }
}
int cost(const vector<int>& individual) { // cost 값 계산
    int cost = 0; // cost 값
    for (const auto& edge : edges) {
        if (individual[edge.v1] != individual[edge.v2]) { // v1과 v2가 서로 연결되었으면
            cost += edge.w; // 연결된 간선의 가중치 값을 더함
        }
    }
    return cost; // cost 값을 반환
}
vector<int> tournament_selection() { // 부모 선택 - 토너먼트 선택 방식
    set<int> chosen;
    int tournament_num = (int)count_V * TRMT_SIZE;
    while (chosen.size() < tournament_num) {
        chosen.insert(rand() % POP_SIZE); // 토너먼트에 참여할 해를 랜덤으로 선택 -> 이 중에서 parent가 나옴
    }
    double tournament_prob = (double)rand() / RAND_MAX;
    if (tournament_prob < TRMT_RATE) { // 0.6보다 작으면 가장 좋은 해를 선택하여 반환
        int best = *chosen.begin(); // 처음 선택된 자식의 index
        for (const auto& idx : chosen) { // 가장 좋은 해를 찾는 for문 
            if (cost(population[idx]) > cost(population[best])) { // cost 값을 비교하여 더 좋은 해가 있으면 그 해의 index로 갱신
                best = idx;
            }
        }
        return population[best]; // 가장 좋은 해(0과 1로 이루어진 individual)를 반환함
    }
    else { // chosen에서 랜덤한 하나의 해를 선택하여 반환
        int ran = rand() % tournament_num;
        auto ran_idx = chosen.begin();
        advance(ran_idx, ran);
        return population[*ran_idx];
    }
}
void crossover(vector<int>& mom, vector<int>& dad) { // 두 부모를 교차(교배)
    vector<int> best_parent; // 더 우수한 parent
    vector<int> worst_parent; // 더 열등한 parent
    if (cost(mom) >= cost(dad)) {
        best_parent = mom;
        worst_parent = dad;
    }
    else {
        best_parent = dad;
        worst_parent = mom;
    }
    if (((double)rand() / RAND_MAX) < CRSOVR_RATE) { // 교차가 일어나면
        int cross_point = (int)(count_V * 0.75); // 3/4 지점까지 우수한 parent가 들어감
        for (int i = 0; i < cross_point; ++i) {
            swap(best_parent[i], worst_parent[i]); // wort_parent에 우수한 부모의 3/4 개의 gene이 들어가게 됨 -> wort_parent에 더 좋은 해가 많아짐
        }
        mom = worst_parent;
        dad = best_parent;
    }
}
void mutate(vector<int>& individual) { // 변이
    for (int& gene : individual) { // gene: individual 컨테이너 내 원소에 대한 참조값(reference)
        if (((double)rand() / RAND_MAX) < MUTN_RATE) { // 변이가 발생하면
            gene = 1 - gene; // 0인 gene은 1로, 1인 gene은 0으로 바뀜
        }
    }
}
//LocalOptimum
void LocalOptimum(vector<int>& parent) {
    vector<int>bestparent = parent;
    int origincost = cost(parent);
    for (int lp = 0; lp < parent.size(); lp++)
    {
        parent[lp] = 1 - parent[lp];
        if (cost(parent) > origincost)
        {
            bestparent = parent;
        }
        parent[lp] = 1 - parent[lp];
    }
    parent = bestparent;
}

vector<int> get_best() {
    int best_idx = 0;
    for (int i = 1; i < POP_SIZE; ++i) {
        if (cost(population[i]) > cost(population[best_idx])) { // 가장 우수한 해 찾음
            best_idx = i;
        }
    }
    return population[best_idx]; // 가장 우수한 해
}

int get_best2(int ps) {
    int best_idx = 0;
    for (int i = 1; i < ps; ++i) {
        if (cost(population[i]) < cost(population[best_idx])) { // 가장 우수한 해 찾음
            best_idx = i;
        }
    }
    return best_idx;
}

vector<int> population_min;
vector<vector<int>> NEWPOP(int ps)
{
    int idx = get_best2(ps);
    vector<vector<int>> updatedPopulation = population;
    population_min.resize(count_V);
    population_min = population[idx];
    updatedPopulation.erase(updatedPopulation.begin() + idx);
    return updatedPopulation;
}

void genetic_algorithm() {
    vector<vector<int>> new_population; // 그 다음 후속 세대가 생성
    for (int i = 0; i < POP_SIZE; ++i) {
        vector<int> mom = tournament_selection();
        vector<int> dad = tournament_selection();
        if (mom == dad) { // 똑같은 부모가 나오면 다시 부모를 선택함
            mom = tournament_selection();
            dad = tournament_selection();
        }
        crossover(mom, dad); // mom과 dad 교차(교배)
        mutate(mom); // 교배했을 때 더 좋은 해(mom)의 변이
        LocalOptimum(mom); //Local Optimum
        new_population.push_back(mom); // 그 다음 후속 세대에 새로운 변이 해 삽입
    }
    //기존 세대에서 elite 2명 뽑음
    //Elite1
    vector<vector<int>>POP = NEWPOP(POP_SIZE);
    vector<int>pop_min = population_min;
    // Elite2
    POP = NEWPOP(POP_SIZE - 1);
    vector<int> population_submin = population_min;
    // Elite2 population에서 삭제
    // elitism 방식으로 대치
    POP.insert(POP.end(), new_population.begin(), new_population.end()); // 현재 세대와 후속 세대 결합
    // fitness 값을 기준으로 결합된 세대를 정렬함
    sort(POP.begin(), POP.end(),
        [](const vector<int>& a, const vector<int>& b) {
            return cost(a) > cost(b);
        });
    POP.resize(POP_SIZE - 2);
    //Elite population에 다시 넣음
    POP.push_back(population_min);
    POP.push_back(population_submin);
    population = POP;
}

int main() {
    clock_t first = clock();
    string inputFile = "maxcut_500.in"; // 입력 파일명
    string outputFile = "maxcut_500.out"; // 출력 파일명
    ifstream inFile(inputFile);
    inFile >> count_V >> count_E; // 정점 개수, 간선 개수 읽기
    for (int i = 0; i < count_E; ++i) {
        int vertax1, vertax2, weight; // 정점1, 정점2, 정점1과 정점2를 잇는 가중치
        inFile >> vertax1 >> vertax2 >> weight;
        edges.push_back({ vertax1 - 1, vertax2 - 1, weight }); // 0부터 시작하기 때문에 1씩 빼줌
    }
    inFile.close();

    initialize_population();
    genetic_algorithm();
    vector<int> best_individual = get_best(); // 가장 우수한 해
    int lastcost = cost(best_individual);
    clock_t last = clock();
    duration = (double)(first - last) / CLOCKS_PER_SEC;
    auto start = chrono::steady_clock::now(); // start: 현재 시간
    for (int gen = 0; gen < GENERATIONS; ++gen) {
        genetic_algorithm();
        vector<int> best_individual = get_best(); // 가장 우수한 해
        int newcost = cost(best_individual);
        if (lastcost < newcost) {
            ofstream outFile(outputFile, ios::trunc);
            for (int i = 0; i < count_V; ++i) {
                if (best_individual[i] == 1) {
                    outFile << i + 1 << " "; // 처음에 inFile의 정점을 읽을 때 1씩 뺐기 때문에 다시 1씩 더함
                }
            }
            outFile.close();
            lastcost = newcost;
        }
        auto end = chrono::steady_clock::now(); // end: ending time
        auto elapsed = chrono::duration_cast<chrono::seconds>(end - start).count(); // elapsed time in seconds
        if (elapsed > (176.0 - duration)) {
            break;
        }
    }
    return 0;
}